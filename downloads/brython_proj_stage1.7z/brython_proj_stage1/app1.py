from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify
from peewee import *
from flask_bcrypt import Bcrypt
import datetime

# 設定 Flask 和資料庫
app = Flask(__name__)
app.secret_key = 'supersecretkey'  # 用來加密 session
bcrypt = Bcrypt(app)

# 設定 SQLite 資料庫
db = SqliteDatabase('robot.sqlite')

# 定義 User 模型
class User(Model):
    account = CharField(unique=True)  # 使用者帳號（學號）
    password = CharField()  # 密碼

    class Meta:
        database = db  # 指定資料庫

# 定義 Program 模型
class Program(Model):
    time = DateTimeField(default=datetime.datetime.now)  # 程式儲存時間
    user = ForeignKeyField(User, backref='programs')  # 相關聯的使用者
    brython = TextField()  # 儲存 Brython 代碼
    from_where = CharField()  # 程式來自何處
    memo = TextField(null=True)  # 額外備註

    class Meta:
        database = db  # 指定資料庫

# 初始化資料庫
db.connect()
db.create_tables([User, Program], safe=True)  # safe=True 表示如果資料表已經存在就不會再次創建

@app.route('/')
def index():
    return render_template('index.html')


# 註冊頁面處理
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        account = request.form['account']
        password = request.form['password']
        confirm_password = request.form['confirm_password']
        
        # 檢查學號是否為 8 位數字
        if len(account) != 8 or not account.isdigit():
            flash("學號必須是 8 位數字！")
            return redirect(url_for('register'))
        
        # 檢查密碼是否一致
        if password != confirm_password:
            flash("兩次密碼輸入不一致！")
            return redirect(url_for('register'))
        
        # 檢查學號是否已註冊
        if User.select().where(User.account == account).exists():
            flash("此學號已被註冊！")
            return redirect(url_for('register'))
        
        # 密碼加密
        hashed_pw = bcrypt.generate_password_hash(password).decode('utf-8')
        
        # 儲存使用者資料
        User.create(account=account, password=hashed_pw)
        
        flash("註冊成功，請登入！")
        return redirect(url_for('login'))

    return render_template('register.html')


# 登入頁面處理
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        account = request.form['account']
        password = request.form['password']
        
        try:
            user = User.get(User.account == account)
        except DoesNotExist:
            flash("帳號或密碼錯誤")
            return redirect(url_for('login'))
        
        # 密碼比對
        if bcrypt.check_password_hash(user.password, password):
            session['user_id'] = user.id  # 登入後儲存 session
            flash("登入成功！")
            return redirect(url_for('brython_test'))
        else:
            flash("帳號或密碼錯誤")
            return redirect(url_for('login'))
    
    return render_template('login.html')


# 登出功能
@app.route('/logout')
def logout():
    session.clear()  # 清除 session
    flash("您已成功登出")
    return redirect(url_for('index'))  # 重新導向到首頁或登入頁面


# Brython 程式測試頁面
@app.route('/brython_test', methods=['GET', 'POST'])
def brython_test():
    if 'user_id' not in session:
        flash("請先登入")
        return redirect(url_for('login'))

    return render_template('brython_test.html')


# 儲存使用者程式碼
@app.route('/save_program', methods=['POST'])
def save_program():
    if 'user_id' not in session:
        return jsonify({"message": "請先登入"}), 401  # 如果沒登入，返回 401 錯誤

    # 取得 JSON 請求的資料
    data = request.get_json()
    brython_code = data.get('brython_code')  # 提取程式碼

    if brython_code:
        # 儲存程式碼到資料庫
        user = User.get(User.id == session['user_id'])
        Program.create(user=user, brython=brython_code, from_where='web', memo='使用者測試程式')

        return jsonify({"message": "程式碼已儲存"}), 200  # 儲存成功
    else:
        return jsonify({"message": "程式碼未提供"}), 400  # 程式碼為空


# 查詢程式碼頁面（包含分頁功能）
@app.route('/programs')
def programs():
    page = request.args.get('page', 1, type=int)
    programs = Program.select().paginate(page, 20)  # 每頁顯示 20 筆
    return render_template('programs.html', programs=programs)


# 主程式啟動
if __name__ == '__main__':
    app.run(debug=True)
