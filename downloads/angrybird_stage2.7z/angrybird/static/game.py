from browser import document, html, timer, ajax

canvas = document["gameCanvas"]
ctx = canvas.getContext("2d")
WIDTH, HEIGHT = 800, 400

# 圖片
bird_img = html.IMG(src="/static/images/bird.png")
pig_img = html.IMG(src="/static/images/pig.png")

# 彈弓位置
SLING_X, SLING_Y = 120, 300
MAX_SHOTS = 10
shots_fired = 0
score = 0
mouse_down = False
mouse_pos = (SLING_X, SLING_Y)
projectile = None

# ------------------------------------------
# 類別
# ------------------------------------------
class Pig:
    def __init__(self,x,y):
        self.x,self.y = x,y
        self.w,self.h = 40,40
        self.alive = True
    def draw(self):
        if self.alive:
            ctx.drawImage(pig_img,self.x,self.y,self.w,self.h)
    def hit(self,px,py):
        return self.alive and self.x<=px<=self.x+self.w and self.y<=py<=self.y+self.h

class Block:
    def __init__(self,x,y,w,h):
        self.x,self.y,self.w,self.h = x,y,w,h
    def draw(self):
        ctx.fillStyle="saddlebrown"
        ctx.fillRect(self.x,self.y,self.w,self.h)

class Bird:
    def __init__(self,x,y,vx,vy):
        self.x,self.y,self.vx,self.vy = x,y,vx,vy
        self.w,self.h = 35,35
        self.active = True
    def update(self):
        global score
        if not self.active: return
        # 重力
        self.vy += 0.35
        self.x += self.vx
        self.y += self.vy
        # 撞地停止
        if self.y > HEIGHT - self.h:
            self.active = False
        # 撞小豬得分
        for p in pigs:
            if p.hit(self.x+self.w/2,self.y+self.h/2):
                if p.alive:
                    p.alive = False
                    score += 50
                    document["score_display"].text = str(score)
                    
    def draw(self):
        ctx.drawImage(bird_img,self.x,self.y,self.w,self.h)

# ------------------------------------------
# 初始化房舍與小豬
# ------------------------------------------
pigs = []
blocks = []

def init_level():
    global pigs, blocks
    pigs=[]
    blocks=[]
    blocks.append(Block(500,300,120,15))
    blocks.append(Block(500,250,15,50))
    blocks.append(Block(605,250,15,50))
    blocks.append(Block(500,235,120,15))
    pigs.append(Pig(545,260))

init_level()

# ------------------------------------------
# 更新剩餘射擊次數
# ------------------------------------------
def update_shots_remaining():
    document["shots_remaining"].text = str(MAX_SHOTS - shots_fired)

# ------------------------------------------
# 滑鼠事件
# ------------------------------------------
def get_mouse_pos(evt):
    return evt.x - canvas.offsetLeft, evt.y - canvas.offsetTop

def mousedown(evt):
    global mouse_down, mouse_pos
    if shots_fired >= MAX_SHOTS: return
    mouse_down = True
    mouse_pos = get_mouse_pos(evt)

def mousemove(evt):
    global mouse_pos
    if mouse_down:
        mouse_pos = get_mouse_pos(evt)

def mouseup(evt):
    global mouse_down, projectile, shots_fired, score
    if shots_fired >= MAX_SHOTS: return
    mouse_down = False
    end_pos = get_mouse_pos(evt)
    dx = SLING_X - end_pos[0]
    dy = SLING_Y - end_pos[1]
    projectile = Bird(SLING_X, SLING_Y, dx*0.25, dy*0.25)
    score = 0
    shots_fired += 1
    update_shots_remaining()

canvas.bind("mousedown", mousedown)
canvas.bind("mousemove", mousemove)
canvas.bind("mouseup", mouseup)

# ------------------------------------------
# 畫彈弓與橡皮筋
# ------------------------------------------
def draw_sling():
    ctx.strokeStyle="black"
    ctx.lineWidth=4
    if mouse_down:
        mx,my = mouse_pos
        # 左右橡皮筋
        ctx.beginPath()
        ctx.moveTo(SLING_X-5, SLING_Y)
        ctx.lineTo(mx,my)
        ctx.stroke()
        ctx.beginPath()
        ctx.moveTo(SLING_X+5, SLING_Y)
        ctx.lineTo(mx,my)
        ctx.stroke()
        # 鳥畫在滑鼠位置
        ctx.drawImage(bird_img,mx-17,my-17,35,35)
    else:
        # 鳥在原點
        ctx.drawImage(bird_img,SLING_X-17,SLING_Y-17,35,35)

# ------------------------------------------
# 傳分數給後端
# ------------------------------------------
sent = False
def send_score():
    global sent
    if sent: return
    sent=True
    req = ajax.Ajax()
    req.open("POST","/submit_score",True)
    req.set_header("Content-Type","application/json")
    req.send({"score":score})

# ------------------------------------------
# 遊戲主迴圈
# ------------------------------------------
def loop():
    global projectile, sent
    ctx.clearRect(0,0,WIDTH,HEIGHT)
    for b in blocks: b.draw()
    for p in pigs: p.draw()
    if projectile:
        projectile.update()
        projectile.draw()
        # 鳥停止後處理
        if not projectile.active:
            projectile = None
            send_score()      # 送分
            init_level()      # 房舍重整
    draw_sling()

timer.set_interval(loop,30)
update_shots_remaining()
document["score_display"].text = str(score)
