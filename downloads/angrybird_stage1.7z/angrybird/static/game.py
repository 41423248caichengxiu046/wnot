from browser import document, html, timer, ajax

canvas = document["gameCanvas"]
ctx = canvas.getContext("2d")
WIDTH, HEIGHT = 800, 400

bird_img = html.IMG(src="/static/images/bird.png")
pig_img = html.IMG(src="/static/images/pig.png")

SLING_X, SLING_Y = 120, 300
MAX_SHOTS = 5
shots_fired = 0
score = 0
mouse_down = False
mouse_pos = (SLING_X, SLING_Y)
projectile = None

# Simple pigs and blocks
class Pig:
    def __init__(self,x,y):
        self.x,self.y= x,y
        self.w,self.h=40,40
        self.alive=True
    def draw(self):
        if self.alive:
            ctx.drawImage(pig_img,self.x,self.y,self.w,self.h)
    def hit(self,px,py):
        return self.alive and self.x<=px<=self.x+self.w and self.y<=py<=self.y+self.h

class Block:
    def __init__(self,x,y,w,h):
        self.x,self.y,self.w,self.h= x,y,w,h
    def draw(self):
        ctx.fillStyle="saddlebrown"
        ctx.fillRect(self.x,self.y,self.w,self.h)

class Bird:
    def __init__(self,x,y,vx,vy):
        self.x,self.y,self.vx,self.vy=x,y,vx,vy
        self.w,self.h=35,35
        self.active=True
    def update(self):
        global score
        if not self.active: return
        self.vy += 0.35
        self.x += self.vx
        self.y += self.vy
        if self.y>HEIGHT-self.h: self.active=False
        for p in pigs:
            if p.hit(self.x+self.w/2,self.y+self.h/2):
                p.alive=False
                score+=50
    def draw(self):
        ctx.drawImage(bird_img,self.x,self.y,self.w,self.h)

# Initialize
pigs=[]
blocks=[]
blocks.append(Block(500,300,120,15))
blocks.append(Block(500,250,15,50))
blocks.append(Block(605,250,15,50))
blocks.append(Block(500,235,120,15))
pigs.append(Pig(545,260))

def update_shots_remaining():
    document["shots_remaining"].text = str(MAX_SHOTS - shots_fired)

def get_mouse_pos(evt):
    return evt.x - canvas.offsetLeft, evt.y - canvas.offsetTop

def mousedown(evt):
    global mouse_down, mouse_pos
    if shots_fired>=MAX_SHOTS: return
    mouse_down=True
    mouse_pos=get_mouse_pos(evt)

def mousemove(evt):
    global mouse_pos
    if mouse_down:
        mouse_pos=get_mouse_pos(evt)

def mouseup(evt):
    global mouse_down, projectile, shots_fired, score
    if shots_fired>=MAX_SHOTS: return
    mouse_down=False
    end_pos=get_mouse_pos(evt)
    dx = SLING_X - end_pos[0]
    dy = SLING_Y - end_pos[1]
    projectile = Bird(SLING_X, SLING_Y, dx*0.25, dy*0.25)
    score=0
    shots_fired+=1
    update_shots_remaining()

canvas.bind("mousedown",mousedown)
canvas.bind("mousemove",mousemove)
canvas.bind("mouseup",mouseup)

def draw_sling():
    ctx.strokeStyle="black"
    ctx.lineWidth=4
    if mouse_down:
        mx,my = mouse_pos
        ctx.beginPath()
        ctx.moveTo(SLING_X-5, SLING_Y)
        ctx.lineTo(mx,my)
        ctx.stroke()
        ctx.beginPath()
        ctx.moveTo(SLING_X+5, SLING_Y)
        ctx.lineTo(mx,my)
        ctx.stroke()
        ctx.drawImage(bird_img,mx-17,my-17,35,35)
    else:
        ctx.drawImage(bird_img,SLING_X-17,SLING_Y-17,35,35)

sent=False
def send_score():
    global sent
    if sent: return
    sent=True
    req = ajax.Ajax()
    req.open("POST","/submit_score",True)
    req.set_header("Content-Type","application/json")
    req.send({"score":score})

def loop():
    ctx.clearRect(0,0,WIDTH,HEIGHT)
    for b in blocks: b.draw()
    for p in pigs: p.draw()
    global projectile
    if projectile:
        projectile.update()
        projectile.draw()
        if not projectile.active:
            projectile=None
            if shots_fired>=MAX_SHOTS:
                send_score()
    draw_sling()

timer.set_interval(loop,30)
update_shots_remaining()
