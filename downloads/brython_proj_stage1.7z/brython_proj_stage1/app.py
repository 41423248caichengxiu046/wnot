from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify
from peewee import *
from flask_bcrypt import Bcrypt
import datetime
import os

# 設定 Flask
app = Flask(__name__)
app.secret_key = os.urandom(24)  # 更安全的 secret_key
bcrypt = Bcrypt(app)

# 設定 SQLite 資料庫
db = SqliteDatabase('robot.sqlite')

# 定義模型
class BaseModel(Model):
    class Meta:
        database = db

class User(BaseModel):
    account = CharField(unique=True)  # 學號
    password = CharField()

class Program(BaseModel):
    time = DateTimeField(default=datetime.datetime.now)
    user = ForeignKeyField(User, backref='programs')
    brython = TextField()
    from_where = CharField(default='web')
    memo = TextField(null=True)

# 初始化資料庫
db.connect()
db.create_tables([User, Program], safe=True)

# 登入檢查裝飾器
def login_required(f):
    from functools import wraps
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash("請先登入")
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

@app.route('/')
def index():
    return render_template('index.html')

# 註冊
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        account = request.form['account'].strip()
        password = request.form['password']
        confirm_password = request.form['confirm_password']

        # 驗證學號
        if not (len(account) == 8 and account.isdigit()):
            flash("學號必須是 8 位數字！")
            return redirect(url_for('register'))

        if password != confirm_password:
            flash("兩次密碼不一致！")
            return redirect(url_for('register'))

        if User.select().where(User.account == account).exists():
            flash("此學號已被註冊！")
            return redirect(url_for('register'))

        # 加密密碼
        hashed_pw = bcrypt.generate_password_hash(password).decode('utf-8')
        User.create(account=account, password=hashed_pw)
        flash("註冊成功！請登入")
        return redirect(url_for('login'))

    return render_template('register.html')

# 登入
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        account = request.form['account'].strip()
        password = request.form['password']

        try:
            user = User.get(User.account == account)
        except User.DoesNotExist:
            flash("帳號或密碼錯誤")
            return redirect(url_for('login'))

        if bcrypt.check_password_hash(user.password, password):
            session['user_id'] = user.id
            flash("登入成功！")
            return redirect(url_for('brython_test'))
        else:
            flash("帳號或密碼錯誤")
            return redirect(url_for('login'))

    return render_template('login.html')

# 登出
@app.route('/logout')
def logout():
    session.clear()
    flash("已成功登出")
    return redirect(url_for('index'))

# Brython 測試頁面
@app.route('/brython_test')
@login_required
def brython_test():
    return render_template('brython_test.html')

# 儲存程式碼
@app.route('/save_program', methods=['POST'])
@login_required
def save_program():
    data = request.get_json()
    brython_code = data.get('brython_code', '').strip()

    if not brython_code:
        return jsonify({"message": "程式碼不能為空"}), 400

    try:
        user = User.get(User.id == session['user_id'])
        Program.create(
            user=user,
            brython=brython_code,
            from_where='web',
            memo='Brython 測試程式'
        )
        return jsonify({"message": "程式碼已儲存"}), 200
    except Exception as e:
        return jsonify({"message": f"儲存失敗: {str(e)}"}), 500

# 程式碼列表（分頁）
@app.route('/programs')
@login_required
def programs():
    page = request.args.get('page', 1, type=int)
    per_page = 20
    programs = (
        Program.select()
        .where(Program.user == session['user_id'])
        .order_by(Program.time.desc())
        .paginate(page, per_page)
    )
    return render_template('programs.html', programs=programs, page=page)

if __name__ == '__main__':
    app.run(debug=True)