# extract_account_password.py
from peewee import *  # 匯入 peewee 模組中的所有功能，用來與 SQLite 資料庫互動

# 設定資料庫連接，指定使用 'stud2.sqlite' 資料庫
db = SqliteDatabase('stud2.sqlite')

# 定義 Student 資料表模型，對應資料庫中的 Student 表
class Student(Model):
    account = CharField(unique=True)  # 帳號欄位，使用文字型別並設定唯一性（unique=True）
    password = CharField()  # 密碼欄位，使用文字型別
    studnum = CharField(null=True)  # 學號欄位，可允許為空值
    memo = CharField(null=True)  # 備註欄位，可允許為空值

    class Meta:
        database = db  # 指定該模型所屬的資料庫

# 透過 Peewee ORM 查詢 Student 資料表中的所有資料
students = Student.select()

# 開啟（或建立）名為 'account_password.txt' 的文字檔，以寫入模式（'w'）開啟
with open('account_password2.txt', 'w') as file:
    # 使用迴圈逐筆讀取資料
    for student in students:
        # 將每位學生的帳號與密碼以「帳號<TAB>密碼」的格式寫入文字檔中
        file.write(f'{student.account}\t{student.password}\n')

# 完成後輸出訊息，提示帳號與密碼已成功匯出
print("帳號與密碼已寫入 account_password2.txt")
