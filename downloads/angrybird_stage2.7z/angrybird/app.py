# app.py
from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify
from peewee import *
from bcrypt import hashpw, gensalt, checkpw
from datetime import datetime
import os

# -----------------------------
# Database
# -----------------------------
db = SqliteDatabase("database.db")

class BaseModel(Model):
    class Meta:
        database = db

class User(BaseModel):
    username = CharField(unique=True)
    password_hash = CharField()

    @staticmethod
    def create_user(username, password):
        hashed = hashpw(password.encode(), gensalt()).decode()
        return User.create(username=username, password_hash=hashed)

class Score(BaseModel):
    user = ForeignKeyField(User, backref='scores')
    score = IntegerField()
    timestamp = DateTimeField(default=datetime.now)

db.connect()
db.create_tables([User, Score])
db.close()

# -----------------------------
# Flask App
# -----------------------------
app = Flask(__name__)
app.config["SECRET_KEY"] = "super_secret_key"

# -----------------------------
# Login decorator
# -----------------------------
def login_required(func):
    def wrapper(*args, **kwargs):
        if "user_id" not in session:
            flash("請先登入")
            return redirect(url_for("login"))
        return func(*args, **kwargs)
    wrapper.__name__ = func.__name__
    return wrapper

# -----------------------------
# Routes
# -----------------------------
@app.route("/")
def index():
    top = Score.select().join(User).order_by(Score.score.desc()).limit(10)
    return render_template("index.html", leaderboard=top)

@app.route("/register", methods=["GET","POST"])
def register():
    if request.method == "POST":
        try:
            User.create_user(
                request.form["username"],
                request.form["password"]
            )
            flash("註冊成功，請登入")
            return redirect(url_for("login"))
        except:
            flash("使用者已存在")
    return render_template("register.html")

@app.route("/login", methods=["GET","POST"])
def login():
    if request.method == "POST":
        username = request.form["username"]
        pw = request.form["password"]

        try:
            user = User.get(User.username == username)
            if checkpw(pw.encode(), user.password_hash.encode()):
                session["user_id"] = user.id
                session["username"] = user.username
                return redirect(url_for("game"))
            else:
                flash("密碼錯誤")
        except User.DoesNotExist:
            flash("無此使用者")

    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    flash("已登出")
    return redirect(url_for("index"))

@app.route("/game")
@login_required
def game():
    return render_template("game.html")

@app.route("/submit_score", methods=["POST"])
@login_required
def submit_score():
    data = request.get_json()
    score_val = int(data.get("score", 0))
    user = User.get_by_id(session["user_id"])
    Score.create(user=user, score=score_val)

    return jsonify({"success": True, "message": "Score saved!"})

if __name__ == "__main__":
    app.run(debug=True)
