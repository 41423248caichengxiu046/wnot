# createdb.py
# 執行此程式前需要安裝以下模組：
# pip install peewee   # Peewee 是一個輕量級 ORM（Object Relational Mapping）工具，用於操作資料庫
# pip install random   # random 是 Python 內建模組，其實無需安裝，但此註解提醒要使用隨機數功能

import random  # 匯入 random 模組，用於生成隨機密碼
import string  # 匯入 string 模組，用於取得英文字母與數字字元
from peewee import *  # 從 peewee 模組中匯入所有類別與方法，以便定義資料庫模型

# 設定 SQLite 資料庫，建立或連接名為 'stud2.sqlite' 的資料庫
db = SqliteDatabase('stud2.sqlite')

# 定義資料表模型 Student，繼承自 peewee 的 Model 類別
class Student(Model):
    account = CharField(unique=True)  # 帳號欄位，使用文字型別（CharField），且設為唯一（unique=True）
    password = CharField()  # 密碼欄位，使用文字型別
    studnum = CharField(null=True)  # 學號欄位，允許為空值（null=True）
    memo = CharField(null=True)  # 備註欄位，允許為空值

    class Meta:
        database = db  # 指定此模型所使用的資料庫為上方建立的 db

# 建立資料庫連線
db.connect()
# 在資料庫中建立 Student 資料表（若不存在）
db.create_tables([Student])

# 定義一個隨機生成密碼的函數
def generate_password():
    chars = string.ascii_uppercase + string.digits  # 定義可用字元（A-Z 與 0-9）
    return ''.join(random.choice(chars) for _ in range(4))  # 隨機挑選 4 個字元並組合成密碼

# 使用 for 迴圈插入 500 筆資料
for i in range(1, 501):  # 從 1 執行到 500（共 500 次）
    account = f'a{i}'  # 帳號名稱為 a1, a2, a3, ..., a500
    password = generate_password()  # 產生隨機密碼
    # 建立 Student 資料表中的一筆新資料（插入帳號與密碼）
    Student.create(account=account, password=password)

print("資料庫已建立並插入 500 筆帳號資料！")  # 顯示成功訊息，表示已成功建立資料庫與資料
