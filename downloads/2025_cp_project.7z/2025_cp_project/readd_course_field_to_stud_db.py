import sqlite3

# 連接資料庫
conn = sqlite3.connect('stud2.sqlite')
cursor = conn.cursor()

# 創建新的資料表 student_new，加入 course 欄位
cursor.execute('''
    CREATE TABLE IF NOT EXISTS student_new (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        course TEXT NOT NULL,
        account TEXT UNIQUE,
        password TEXT,
        studnum TEXT,
        memo TEXT,
        inner_port INTEGER,
        outter_port INTEGER
    )
''')

# 將舊資料表 student 的資料搬移到 student_new，course 欄位先填空字串
cursor.execute('''
    INSERT INTO student_new (course, account, password, studnum, memo, inner_port, outter_port)
    SELECT '', account, password, studnum, memo, inner_port, outter_port FROM student
''')

# 刪除舊資料表
cursor.execute('DROP TABLE IF EXISTS student')

# 將新資料表重新命名為舊資料表名稱
cursor.execute('ALTER TABLE student_new RENAME TO student')

# 提交更改並關閉資料庫
conn.commit()
conn.close()

print("資料表結構已經更新，並成功新增 'course' 欄位。")
