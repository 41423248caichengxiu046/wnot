# 更新 stud2.sqlite 資料庫，為 student 表新增 inner_port 和 outter_port 欄位，並自動填入值
from peewee import *
import sqlite3

# 連接到現有資料庫
db = SqliteDatabase('stud2.sqlite')

# 定義學生資料表模型
class Student(Model):
    id = AutoField()
    account = CharField(unique=True)
    password = CharField()
    studnum = CharField(null=True)
    memo = CharField(null=True)
    inner_port = IntegerField(null=True)   # 內部端口
    outter_port = IntegerField(null=True)  # 外部端口

    class Meta:
        database = db

# 1. 連接資料庫
db.connect()

# 2. 確保資料表存在
db.create_tables([Student])

# 3. 新增欄位 (SQLite 支援 ALTER TABLE ADD COLUMN)
with db.atomic():
    db.execute_sql('ALTER TABLE student ADD COLUMN inner_port INTEGER')
    db.execute_sql('ALTER TABLE student ADD COLUMN outter_port INTEGER')

# 4. 為每筆學生資料分配內外部端口
students = Student.select()
inner_port_value = 8001
outter_port_value = 9001

for student in students:
    student.inner_port = inner_port_value
    student.outter_port = outter_port_value
    student.save()
    inner_port_value += 1
    outter_port_value += 1

print("資料已更新，已成功為每筆資料新增內外部端口！")
