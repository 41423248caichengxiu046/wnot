from flask import Flask, render_template, request, redirect, url_for
from peewee import *
import sqlite3

# 設定資料庫連接
db = SqliteDatabase('stud2.sqlite')

# 定義學生資料表模型
class Student(Model):
    id = AutoField()             # 自動生成主鍵欄位
    course = CharField()         # 課程欄位
    account = CharField(unique=True)
    password = CharField()
    studnum = CharField(null=True)
    memo = CharField(null=True)
    inner_port = IntegerField(null=True)
    outter_port = IntegerField(null=True)

    class Meta:
        database = db

# 定義 Flask 應用
app = Flask(__name__)

# 第一階段的通關密碼
CORRECT_PASSWORD = "thepassword"

# 首頁路由
@app.route('/')
def home():
    return render_template('login.html')

# 驗證第一階段密碼
@app.route('/validate_password', methods=['POST'])
def validate_password():
    entered_password = request.form.get('password')
    if entered_password == CORRECT_PASSWORD:
        return redirect(url_for('course_selection'))
    return render_template('login.html', error="抱歉, 請洽管理者!")

# 課程選擇頁面
@app.route('/course_selection')
def course_selection():
    return render_template('course_selection.html')

# 處理課程選擇與分配帳號
@app.route('/submit_course', methods=['POST'])
def submit_course():
    selected_course = request.form.get('course')
    student_number = request.form.get('studnum')
    student_name = request.form.get('name')

    # 查詢 course 資料庫
    conn = sqlite3.connect('course_num_name2.sqlite')
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM course WHERE course=? AND number=? AND name=?', 
                   (selected_course, student_number, student_name))
    result = cursor.fetchone()
    conn.close()

    if not result:
        return "資料錯誤，請洽管理者"

    # 檢查是否已分配
    student = Student.select().where(Student.studnum==student_number, Student.course==selected_course).first()
    if student:
        return render_template('login.html', error="已經分配過，若有問題請洽管理者.")

    # 找出尚未分配的帳號
    student_to_assign = Student.select().where(Student.studnum.is_null()).first()
    if not student_to_assign:
        return render_template('login.html', error="所有帳號已經被分配，請洽管理者.")

    # 分配學號與課程
    student_to_assign.studnum = student_number
    student_to_assign.course = selected_course
    student_to_assign.save()

    # 顯示帳號、密碼、端口與說明
    return render_template('show_account.html',
                           account=student_to_assign.account,
                           password=student_to_assign.password,
                           inner_port=student_to_assign.inner_port,
                           outter_port=student_to_assign.outter_port,
                           explanation=f"""
                           請利用帳號 {student_to_assign.account} 及密碼 {student_to_assign.password} 登入 s5.eng.nfu.edu.tw。<br/>
                           指令為: ssh {student_to_assign.account}@s5.eng.nfu.edu.tw，輸入由英文大寫字母與數字所組成的密碼後登入。<br /><br />
                           登入後將 {student_to_assign.inner_port} 設定在 server.py 後，<br />
                           您將可以透過 <a href="https://s5.eng.nfu.edu.tw:{student_to_assign.outter_port}">https://s5.eng.nfu.edu.tw:{student_to_assign.outter_port}</a> 連線至動態編輯網頁，<br /><br />
                           並使用 <a href="https://s5.eng.nfu.edu.tw/~{student_to_assign.account}">https://s5.eng.nfu.edu.tw/~{student_to_assign.account}</a> 連線至帳號下的 public_html 目錄中的靜態網頁資料。<br /><br />
                           請隨即<strong>利用手機拍下本頁面資料</strong>，在本學期課程結束前保護好您的帳號與密碼，並確認所有埠號設定正確。""")

# 管理者帳號登入
@app.route('/alogin', methods=['GET', 'POST'])
def alogin():
    if request.method == 'POST':
        account = request.form.get('account')
        password = request.form.get('password')
        if account == "theaccount" and password == "thepassword":
            return render_template('find_studnum.html')
        return render_template('alogin.html', error="帳號或密碼錯誤")
    return render_template('alogin.html')

# 查詢 studnum
@app.route('/find_studnum', methods=['POST'])
def find_studnum():
    studnum = request.form.get('studnum')
    students = Student.select().where(Student.studnum.contains(studnum))
    if students:
        return render_template('show_multiple_students.html', students=students)
    return render_template('find_studnum.html', error="未找到對應的學生資料")

if __name__ == '__main__':
    app.run(debug=True)
