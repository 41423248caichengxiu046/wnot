import sqlite3  # 引入 sqlite3 模組，用於與 SQLite 資料庫進行互動

conn = sqlite3.connect('course_num_name.sqlite')  # 連接或創建名為 'course_num_name.sqlite' 的 SQLite 資料庫
cursor = conn.cursor()  # 創建一個游標物件，後續的 SQL 操作會通過這個游標執行

# 創建表格 'course_num_name'，如果表格已存在則不再創建
cursor.execute('''
CREATE TABLE IF NOT EXISTS course_num_name (  # 如果資料表 'course_num_name' 不存在，則創建
    id INTEGER PRIMARY KEY AUTOINCREMENT,  # id 欄位為自動遞增的整數，作為主鍵
    course TEXT,  # course 欄位，儲存課程編號，型別為 TEXT
    number TEXT,  # number 欄位，儲存課程編號，型別為 TEXT
    name TEXT  # name 欄位，儲存課程名稱，型別為 TEXT
);
''')

conn.commit()  # 提交對資料庫的所有變更，將創建的表格儲存到資料庫中
conn.close()  # 關閉資料庫連線，釋放資源

print("空的 course_num_name.sqlite 資料庫已建立！")  # 輸出成功訊息，告知資料庫已成功建立
