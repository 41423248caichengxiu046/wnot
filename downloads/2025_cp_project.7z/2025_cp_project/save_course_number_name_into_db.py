from peewee import *
import os

# 設定資料庫連接
db = SqliteDatabase('course_num_name2.sqlite')

# 定義課程資料表模型
class Course(Model):
    course = CharField()  # 課程名稱（例如 1a）
    number = CharField()  # 學號
    name = CharField()    # 姓名

    class Meta:
        database = db

# 設置資料庫連接
db.connect()

# 確保資料表存在
db.create_tables([Course])

# 讀取檔案並寫入資料庫的函式
def import_course_data(filename, course_name):
    try:
        # 讀取檔案
        with open(filename, 'r', encoding='utf-8') as file:
            for line in file:
                # 拆分每行的學號和姓名
                parts = line.strip().split('\t')  # 使用 tab 拆分
                if len(parts) == 2:  # 確保每行資料都有學號和姓名
                    number, name = parts
                    # 寫入資料庫
                    Course.create(course=course_name, number=number, name=name)
                    print(f"已將 {number} - {name} 寫入資料庫")
    except Exception as e:
        print(f"讀取檔案 {filename} 時發生錯誤: {e}")

# 依次讀取各個檔案並寫入資料庫
file_list = ['1a_num_name2.txt', '1b_num_name2.txt', '2a_num_name2.txt', '2b_num_name2.txt']
for file in file_list:
    course_name = file.split('_')[0]  # 取檔名的第一部分作為課程名稱
    if os.path.exists(file):
        import_course_data(file, course_name)
    else:
        print(f"檔案 {file} 不存在！")
